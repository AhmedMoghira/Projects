When programm starting it begin to define or declare all the variables ,
Execution : Execute the program begin from the main function , the program begin to execute all the instructions from first to end in Order.

Setter ob : an object created from the Setter class and it carry or inherite all the properties
of  that class.
object call for set all the values for all prevoius declared variables.
ob.userOptions :
the object which created from Setter class can call userOption function
there is like a Stringly window  display on the screen when userOption function called , and  compiler weit you to enter 1 if you want go to option or 0  if you want to start playing .

0 go to last line in the function and program should be ready to execute the next instruction.
While loop :
it executed when gameEnded is false  and opposite right .
interface ob2 : an object created from interface class for run constructor and it is loops of interface class.
Input :
input class  responsible from snake movement, when it call it wait the user to tap on keyboard .
Logic  ob4 :
after object interface class called ,the class Logic will start excution.  if user tap on keyboard in the input class it will waiting user for tap on the keyboard.
Compiler will declare or define many variable.during Logic class calling and then if one  of the three "if"  statement accure. the game Over.



I use those :
system("cls");  for clear  screen .
Sleep(L) : for increase or decrease speed  of  the game.
system ("Color c"); to change  Color to red;
include<conio.h >windows.h : as library  to
system ("cls"); 

include<windows.h > for system ("Color c");

- include<unistd.h>  for sleep();

