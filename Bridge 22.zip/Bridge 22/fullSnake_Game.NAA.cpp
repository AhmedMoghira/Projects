/*We do this project by Embarcadero Dev-C++ .....
Note.....online compiler do not work with this project.

do it by Nasr Eldeen, and Ahmed ,and Alaa */
#include <iostream>

#include<conio.h>

#include<windows.h>

#include<fstream>

#include<unistd.h>

using namespace std;

//bool paused = false;
bool gameEnded;
const int Width = 25;
const int Height = 15;
int x, y, FruitX, FruitY, Score, bestScore = 0;
int TailX[100], TailY[100];
int nTail;
int fullScore = 100;
enum eDirecton {
    STOP = 0, LEFT, RIGHT, UP, DOWN
};
eDirecton dir;
int L;

class Setter
{
    public: Setter()
    {
        gameEnded = false;
        dir = STOP;
        x = Width / 2;
        y = Height / 2;
        FruitX = rand() % Width;
        FruitY = rand() % Height;
        Score = 0;
        nTail = 0;
        L = 0;
        bool paused = false;

    }
    void userOption()
    {
        int Selectnum;
        bool check = false;
        cout << "#************WELLCOM BACK*************#" << endl;
        cout << "#  if  you want start playing Enter 0 #" << endl;
        cout << "# & Enter 1 if  you want go to Options#" << endl;
        cout << "#                                     #" << endl;
        cout << "#*************************************#" << endl;
        cout << "****** Start playing ***** Options ****" << endl;
        cin >> check;
        cout << endl;
        if (check)
        {
            cout << "1.the game levels" << endl;
            cout << "2.instructions" << endl;
            cout << "3.previous grades" << endl;
            cout << "select the number of the option : ";
            cin >> Selectnum;
            cout << endl << endl;

            switch (Selectnum)
            {
                case 1:

                    cout << "1.hard" << endl;
                    cout << "2.medium" << endl;
                    cout << "3.easy" << endl;
                    cout << "select the number of the option : ";
                    cin >> Selectnum;

                    switch (Selectnum)
                    {
                        sleep(4);
                        case 1:
                            L = 30;

                            cout << "click 1 if you want come back and 0 to start playing" << endl;
                            cin >> check;

                            if (check)
                                userOption();

                            break;
                        case 2:

                            L = 60;

                            cout << "click 1 if you want come back and 0 to start playing" << endl;
                            cin >> check;

                            if (check)
                                userOption();

                            break;
                        case 3:

                            L = 100;

                            cout << "click 1 if you want come back and 0 to start playing" << endl;
                            cin >> check;

                            if (check)
                                userOption();
                            break;
                    }
                    break;
                case 2:

                    cout << "move the snake for eating food and grows and avoid toutching wall or the snake tail.  " << endl << endl;
                    cout << "click 1 if you wnat come back and 0 to start playing" << endl;
                    cin >> check;

                    if (check)
                        userOption();

                    break;
                case 3:
                    ifstream readfile("cref.cpp");

                    string text = "prevoius grades : ";
                    int b;
                    cout << text << endl;
                    while (readfile >> text >> b)

                    {
                        if (b >= bestScore)
                        {
                            bestScore = b;
                        }
                        cout << endl << b << endl;
                    }
                    cout << " best Score :" << bestScore << endl;

                    cout << endl << "click 1 if you wnat come back and 0 to start playing" << endl;
                    cin >> check;
                    if (check)
                        userOption();
                    break;
            }
        }
        else
        {

            cout << "THE GAME WILL START AFTER " << 3 << " seconds" << endl;
            sleep(3);
        }
    }

};

class interFace
{
    public: interFace()
    {
        system("cls");
        system("color b");


        for (int i = 0; i < Width + 2; i++)
            cout << "#";
        cout << endl;


        for (int i = 0; i < Height; i++)
        {
            for (int j = 0; j < Width; j++)
            {
                if (j == 0)
                    cout << "#";

                if (i == y && j == x)
                    cout << "O";
                else if (i == FruitY && j == FruitX)
                    cout << "@";


                else
                {
                    bool print = false;
                    for (int k = 0; k < nTail; k++)
                    {
                        if (TailX[k] == j && TailY[k] == i)
                        {
                            cout << "o";
                            print = true;
                        }

                    }
                    if (!print)
                        cout << " ";
                }


                if (j == Width - 1)

                    cout << "#";

            }
            cout << endl;
        }

        for (int i = 0; i < Width + 2; i++)

            cout << "#";
        cout << endl;
    }
    void display()
    {
        cout << "Score : " << Score << endl;
        cout << "Keyboard Keys :\n";
        cout << "w -  Up\n";
        cout << "s - Down\n";
        cout << "a - Left\n";
        cout << "d - Right\n";
        cout << "x - Quit\n";
        // cout << "Press  p  to Pause game/ Resume game\n";
    }

};


class Input
{
    public: Input()
    {
        if (_kbhit())
        {
            //            if (_getch()=='p')
            //            {
            //            	paused = !paused;
            //            }
            //           else 
            //	{
            switch (_getch())
            {
                case 'a':
                    dir = LEFT;
                    break;
                case 'd':
                    dir = RIGHT;
                    break;
                case 'w':
                    dir = UP;
                    break;
                case 's':
                    dir = DOWN;
                    break;
                case 'x':
                    gameEnded = true;
                    break;
            }
            // }
        }
    }


};
class Logic
{

    public: Logic()
    {
        //if (!paused) {
        int prevX = TailX[0];
        int prevY = TailY[0];
        int prev2X, prev2Y;
        TailX[0] = x;
        TailY[0] = y;
        for (int i = 1; i < nTail; i++)
        {
            prev2X = TailX[i];
            prev2Y = TailY[i];
            TailX[i] = prevX;
            TailY[i] = prevY;
            prevX = prev2X;
            prevY = prev2Y;

        }

        switch (dir)
        {

            case LEFT:
                x--;
                break;
            case RIGHT:
                x++;
                break;
            case UP:
                y--;
                break;
            case DOWN:
                y++;
                break;

        }
        //}

        // wrap around the map 
        // horizontally

        //  if (x >= Width)  x = 0;
        //     else if (x < 0)  x = Width - 1;

        // vertically
        //if (y >= Height) y = 0;
        //  else if (y < 0)   y = Height - 1;


        if (x >= Width || x <= 0 || y >= Height || y <= -0)
        {
            fstream addition("cref.cpp", std::ios::app);
            addition << Score << endl;
            addition.close();

            system("cls");
            system("color c");
            cout << "==========================" << endl;
            cout << "      Game Over       " << endl << "YOU LOSE THE GAME !" << endl << "  Your Score: " << Score << endl;
            cout << "==========================" << endl << endl;
            cout << "Press R to back to opions...Or press any input kay except R to Exit from the Game" << endl;

            char choice;
            while (true)
            {
                choice = _getch();
                if (choice == 'r' || choice == 'R')
                {
                    system("cls");
                    Setter ob5;
                    ob5.userOption();
                    gameEnded = false;
                    system("cls");
                    break;
                }
                else
                {
                    gameEnded = true;
                    break;
                }

            }

        }

        for (int i = 0; i < nTail; i++)
        {
            if (TailX[i] == x && TailY[i] == y)
            {
                fstream addition1("cref.cpp", std::ios::app);

                addition1 << Score << endl;

                addition1.close();
                system("cls");
                system("color c");
                cout << "==========================" << endl;
                cout << "      Game Over       " << endl << "YOU LOSE THE GAME !" << endl << "  Your Score: " << Score << endl;
                cout << "==========================" << endl << endl;
                cout << "Press R to back to opions...Or press any input kay except R to Exit from the Game" << endl;

                char choice;
                while (true)
                {
                    choice = _getch();
                    if (choice == 'r' || choice == 'R')
                    {
                        system("cls");
                        Setter ob6;
                        ob6.userOption();
                        gameEnded = false;
                        system("cls");
                        break;
                    }
                    else
                    {
                        gameEnded = true;
                        break;
                    }

                }
            }

        }

        if (x == FruitX && y == FruitY)
        {
            Score += 10;
            FruitX = rand() % Width;
            FruitY = rand() % Height;
            nTail++;
            if (Score == fullScore)
            {

                fstream addition2("cref.cpp", std::ios::app);
                addition2 << Score << endl;

                addition2.close();
                system("cls");
                system("color A");
                cout << "==========================" << endl;
                cout << "      Game Over       " << endl << "YOU WON THE GAME.!" << endl << "     Your Score: " << Score << endl;
                cout << "==========================" << endl << endl;
                cout << "Press R to back to opions.....Or press any input kay except R to Exit from the Game" << endl;
                char choice;
                while (true)
                {
                    choice = _getch();
                    if (choice == 'r' || choice == 'R')
                    {

                        system("cls");
                        Setter ob7;
                        ob7.userOption();
                        gameEnded = false;
                        system("cls");
                        break;
                    }
                    else
                    {
                        gameEnded = true;
                        break;
                    }

                }
            }
            //}
        }

    }


};

int main()
{
    Setter ob;
    ob.userOption();
    while (!gameEnded)
    {
        interFace ob2;
        ob2.display();
        Sleep(L);
        Input ob3;
        Logic ob4;
    }

}